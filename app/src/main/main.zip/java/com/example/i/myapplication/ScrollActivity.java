package com.example.i.myapplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Jason.Su on 2015/7/30.
 */
public class ScrollActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_scroll);
    }
    private void  init(){

    }
}
